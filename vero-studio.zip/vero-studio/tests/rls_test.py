#!/usr/bin/env python3
"""Test uprawnień w prawdziwym Postgresie: czy każdy widzi i może tylko to, co powinien.
Uruchom po zastosowaniu tests/supabase-stub.sql i supabase/schema.sql (właściciel: owner@example.com)."""
import json, subprocess, sys

DB = ['psql', '-h', '/tmp/pg', '-p', '5433', '-U', 'postgres', '-d', 'vero_test', '-X', '-q', '-At', '-v', 'ON_ERROR_STOP=1']
U = {
    'owner': ('00000000-0000-0000-0000-0000000000a1', 'Owner@Example.com', 'Wiktoria Właścicielka'),
    'w1': ('00000000-0000-0000-0000-0000000000b1', 'ola@example.com', 'Ola Fotograf'),
    'w2': ('00000000-0000-0000-0000-0000000000b2', 'pawel@example.com', 'Paweł Filmowiec'),
    'w3': ('00000000-0000-0000-0000-0000000000b3', 'kasia@example.com', 'Kasia Budka'),
    'stranger': ('00000000-0000-0000-0000-0000000000c1', 'ktos@example.com', 'Ktoś Obcy'),
}
passed = failed = 0


def run(role, sql, uid=None):
    """role: postgres | anon | owner | w1.. (authenticated jako ten użytkownik)."""
    pre = ''
    if role == 'anon':
        pre = "set local role anon;\n"
    elif role != 'postgres':
        i, mail, name = U[role]
        claims = json.dumps({'sub': i, 'email': mail, 'role': 'authenticated', 'user_metadata': {'full_name': name}})
        pre = "set local role authenticated;\nselect set_config('request.jwt.claims', '%s', true) \\gset\n" % claims.replace("'", "''")
    sql = sql.rstrip()
    if not sql.endswith(';'):
        sql += ';'
    script = "\\set VERBOSITY verbose\nbegin;\n%s%s\ncommit;\n" % (pre, sql)
    p = subprocess.run(DB, input=script, capture_output=True, text=True)
    return p.returncode, p.stdout.strip(), p.stderr.strip()


def check(name, cond, detail=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ' + name)
    else:
        failed += 1
        print('  FAIL ' + name + (' -> ' + detail if detail else ''))


def allowed(name, role, sql):
    rc, out, err = run(role, sql)
    check(name, rc == 0, err)
    return out


def denied(name, role, sql, needle=None):
    rc, out, err = run(role, sql)
    check(name, rc != 0 and (needle is None or needle in err), 'rc=%s out=%s err=%s' % (rc, out, err))


def count(role, sql):
    rc, out, err = run(role, sql)
    return int(out) if rc == 0 and out.lstrip('-').isdigit() else -1


# ---------- przygotowanie ----------
run('postgres', "truncate public.payments, public.signups, public.inquiries, public.sessions, public.profiles cascade; delete from auth.users;")
for k, (i, mail, _) in U.items():
    rc, _, err = run('postgres', "insert into auth.users (id, email) values ('%s', '%s');" % (i, mail))
    assert rc == 0, err

print('Profile i rejestracja')
rc, out, err = run('owner', "select role || '/' || approved from public.ensure_profile();")
check('konto z adresem właściciela dostaje rolę owner i dostęp (wielkość liter bez znaczenia)', out == 'owner/true', out + err)
rc, out, err = run('w1', "select role || '/' || approved from public.ensure_profile();")
check('zwykłe konto czeka na zatwierdzenie', out == 'worker/false', out + err)
for w in ('w2', 'w3', 'stranger'):
    run(w, 'select public.ensure_profile();')
rc, out, err = run('w1', "select count(*) from public.profiles;")
check('wywołanie ensure_profile drugi raz nic nie dubluje', count('postgres', "select count(*) from public.profiles where id='%s'" % U['w1'][0]) == 1)
denied('klient bez logowania nie wywoła ensure_profile', 'anon', 'select public.ensure_profile();', 'permission denied')

# dane startowe od właściciela
allowed('właściciel dodaje przyszłą sesję', 'owner', """
insert into public.sessions (id, title, client, event_date, slots) values
 ('10000000-0000-0000-0000-000000000001', 'Wesele Ani i Marka', 'Ania', current_date + 30,
  '{"photographer":{"n":2,"rate":400},"photobooth":{"n":1,"rate":800}}');""")
allowed('właściciel dodaje przeszłą sesję', 'owner', """
insert into public.sessions (id, title, client, event_date, slots) values
 ('10000000-0000-0000-0000-000000000002', 'Osiemnastka Kuby', 'Kuba', current_date - 10,
  '{"photographer":{"n":1,"rate":300}}');""")
S_FUT = '10000000-0000-0000-0000-000000000001'
S_PAST = '10000000-0000-0000-0000-000000000002'
allowed('właściciel dopisuje zapis z przeszłości (historia do rozliczeń)', 'postgres',
        "insert into public.signups (session_id, role, user_id) values ('%s','photographer','%s');" % (S_PAST, U['w1'][0]))

print('Pracownik czekający na zatwierdzenie')
check('nie widzi sesji', count('w2', 'select count(*) from public.sessions') == 0)
check('nie widzi zapisów', count('w2', 'select count(*) from public.signups') == 0)
check('nie widzi wypłat', count('w2', 'select count(*) from public.payments') == 0)
check('widzi tylko swój profil', count('w2', 'select count(*) from public.profiles') == 1)
denied('nie zapisze się na rolę', 'w2', "insert into public.signups (session_id, role, user_id) values ('%s','photographer','%s');" % (S_FUT, U['w2'][0]))
denied('nie zatwierdzi sam siebie', 'w2', "select public.set_approved('%s', true);" % U['w2'][0], 'not_owner')
check('próba podniesienia swojej roli zmienia 0 wierszy', count('w2', "with u as (update public.profiles set approved = true, role='owner' where id='%s' returning 1) select count(*) from u" % U['w2'][0]) in (-1, 0))
check('nadal niezatwierdzony', count('postgres', "select count(*) from public.profiles where id='%s' and approved" % U['w2'][0]) == 0)

print('Zatwierdzanie przez właściciela')
denied('pracownik nie zatwierdzi innych', 'w1', "select public.set_approved('%s', true);" % U['w2'][0], 'not_owner')
denied('pracownik nie pobierze listy kont z e-mailami', 'w1', 'select * from public.owner_people();', 'not_owner')
denied('klient bez logowania nie zatwierdzi', 'anon', "select public.set_approved('%s', true);" % U['w2'][0], 'permission denied')
out = allowed('właściciel widzi listę kont z e-mailami', 'owner', 'select count(*) from public.owner_people();')
check('na liście są wszystkie 5 kont', out == '5', out)
for w in ('w1', 'w2', 'w3'):
    allowed('właściciel zatwierdza ' + w, 'owner', "select public.set_approved('%s', true);" % U[w][0])
run('owner', "select public.set_approved('%s', false);" % U['owner'][0])
check('konta właściciela nie da się zablokować', count('postgres', "select count(*) from public.profiles where role='owner' and approved") == 1)

print('Zatwierdzony pracownik: sesje i zapisy')
check('widzi sesje', count('w1', 'select count(*) from public.sessions') == 2)
check('widzi stawki w sesji', run('w1', "select slots->'photographer'->>'rate' from public.sessions where id='%s'" % S_FUT)[1] == '400')
check('widzi imiona współpracowników (wszystkie 5 kont)', count('w1', 'select count(*) from public.profiles') == 5)
denied('nie czyta adresów e-mail innych', 'w1', "select email from public.profiles;", 'permission denied')
denied('nie dodaje sesji', 'w1', "insert into public.sessions (title, event_date) values ('X', current_date + 1);")
check('nie zmieni sesji', count('w1', "with u as (update public.sessions set title='X' returning 1) select count(*) from u") == 0)
check('nie usunie sesji', count('w1', "with d as (delete from public.sessions returning 1) select count(*) from d") == 0)
allowed('zapisuje się na przyszłą sesję', 'w1', "insert into public.signups (session_id, role, user_id) values ('%s','photographer','%s');" % (S_FUT, U['w1'][0]))
denied('nie zapisze się dwa razy na tę samą rolę', 'w1', "insert into public.signups (session_id, role, user_id) values ('%s','photographer','%s');" % (S_FUT, U['w1'][0]), 'unique')
denied('nie zapisze kogoś innego', 'w1', "insert into public.signups (session_id, role, user_id) values ('%s','photographer','%s');" % (S_FUT, U['w3'][0]))
denied('nie zapisze się na sesję z przeszłości', 'w3', "insert into public.signups (session_id, role, user_id) values ('%s','photographer','%s');" % (S_PAST, U['w3'][0]))
denied('nie zapisze się na nieznaną rolę', 'w3', "insert into public.signups (session_id, role, user_id) values ('%s','dron','%s');" % (S_FUT, U['w3'][0]))
allowed('drugi pracownik też się zapisuje (kolejka)', 'w3', "insert into public.signups (session_id, role, user_id) values ('%s','photographer','%s');" % (S_FUT, U['w3'][0]))
check('wszyscy widzą zapisy całej ekipy', count('w3', 'select count(*) from public.signups') == 3)
check('cudzego zapisu nie usunie', count('w3', "with d as (delete from public.signups where user_id='%s' and session_id='%s' returning 1) select count(*) from d" % (U['w1'][0], S_FUT)) == 0)
check('z przeszłej sesji nie zrezygnuje', count('w1', "with d as (delete from public.signups where session_id='%s' returning 1) select count(*) from d" % S_PAST) == 0)
check('rezygnuje ze swojego zapisu', count('w3', "with d as (delete from public.signups where user_id='%s' and session_id='%s' returning 1) select count(*) from d" % (U['w3'][0], S_FUT)) == 1)
check('właściciel usuwa cudzy zapis', count('owner', "with d as (delete from public.signups where user_id='%s' and session_id='%s' returning 1) select count(*) from d" % (U['w1'][0], S_FUT)) == 1)
check('zapis z przeszłości został', count('postgres', "select count(*) from public.signups where session_id='%s'" % S_PAST) == 1)

print('Wypłaty')
allowed('właściciel zapisuje wypłatę pracownika 1', 'owner', "insert into public.payments (session_id, role, user_id, amount) values ('%s','photographer','%s',300);" % (S_PAST, U['w1'][0]))
allowed('właściciel zapisuje wypłatę pracownika 3', 'postgres', "insert into public.payments (session_id, role, user_id, amount) values ('%s','photobooth','%s',800);" % (S_FUT, U['w3'][0]))
check('pracownik widzi tylko swoją wypłatę', count('w1', 'select count(*) from public.payments') == 1)
check('inny pracownik nie widzi cudzej wypłaty', count('w3', "select count(*) from public.payments where user_id='%s'" % U['w1'][0]) == 0)
check('czekający pracownik nie widzi wypłat', count('stranger', 'select count(*) from public.payments') == 0)
check('właściciel widzi wszystkie wypłaty', count('owner', 'select count(*) from public.payments') == 2)
denied('pracownik nie doda sobie wypłaty', 'w1', "insert into public.payments (session_id, role, user_id, amount) values ('%s','photographer','%s',9999);" % (S_PAST, U['w1'][0]))
check('pracownik nie zmieni kwoty', count('w1', "with u as (update public.payments set amount = 9999 returning 1) select count(*) from u") == 0)
check('pracownik nie usunie wypłaty', count('w1', "with d as (delete from public.payments returning 1) select count(*) from d") == 0)
check('kwota bez zmian', count('postgres', "select count(*) from public.payments where amount = 300") == 1)

print('Zapytania klientów (bez logowania)')
VALID = {"name": "Anna Nowak", "email": "Anna@Example.com", "phone": "600100200", "category": "wesele",
         "date": None, "start": "15:00", "hours": "7-8 godz.", "location": "Kraków, Dwór Zielony", "guests": "80",
         "services": ["photographer", "photobooth"], "counts": {"photographer": 2}, "details": "Reportaż i fotobudka"}


def submit(role, over=None):
    d = dict(VALID); d.update(over or {})
    if d['date'] is None:
        d['date'] = '__FUTURE__'
    sql = "select public.submit_inquiry(replace($j$%s$j$, '__FUTURE__', (current_date + 45)::text)::jsonb);" % json.dumps(d)
    return run(role, sql)


denied('klient nie czyta tabeli zapytań', 'anon', 'select * from public.inquiries;', 'permission denied')
denied('klient nie wpisze nic bezpośrednio do tabeli', 'anon', "insert into public.inquiries (name) values ('x');", 'permission denied')
denied('klient nie czyta sesji', 'anon', 'select * from public.sessions;', 'permission denied')
denied('klient nie czyta profili', 'anon', 'select * from public.profiles;', 'permission denied')
rc, out, err = submit('anon')
check('poprawne zapytanie przechodzi', rc == 0 and len(out) == 36, out + err)
row = run('postgres', "select lower(email) || '|' || category || '|' || services::text || '|' || counts::text || '|' || status from public.inquiries limit 1;")[1]
check('zapisane poprawnie (e-mail małymi literami, liczba fotografów, status new)', row == 'anna@example.com|wesele|{photobooth,photographer}|{"photographer": 2}|new', row)
for name, over, needle in [
    ('zły e-mail', {'email': 'nie-email'}, 'invalid_input:email'),
    ('pusta nazwa', {'name': '  '}, 'invalid_input:name'),
    ('nieznana kategoria', {'category': 'hakowanie'}, 'invalid_input:category'),
    ('data z przeszłości', {'date': '2020-01-01'}, 'invalid_input:date'),
    ('data za daleko', {'date': '2099-01-01'}, 'invalid_input:date'),
    ('śmieciowa data', {'date': 'jutro'}, 'invalid_input:date'),
    ('nieznana usługa', {'services': ['dron']}, 'invalid_input:services'),
    ('brak usług', {'services': []}, 'invalid_input:services'),
    ('liczba spoza zakresu', {'counts': {'photographer': 40}}, 'invalid_input:counts'),
    ('liczba dla niezaznaczonej usługi', {'services': ['photobooth'], 'counts': {'photographer': 2}}, 'invalid_input:counts'),
    ('brak miejsca', {'location': ''}, 'invalid_input:location'),
    ('za długi opis', {'details': 'x' * 3001}, 'invalid_input:details'),
    ('zła godzina', {'start': '3pm'}, 'invalid_input:start'),
]:
    rc, out, err = submit('anon', over)
    check('odrzuca: ' + name, rc != 0 and needle in err, err)
before = count('postgres', 'select count(*) from public.inquiries')
rc, out, err = submit('anon', {'website': 'http://spam.example', 'email': 'bot@example.com'})
check('bot z wypełnioną pułapką dostaje "sukces"', rc == 0 and len(out) == 36)
check('ale nic się nie zapisuje', count('postgres', 'select count(*) from public.inquiries') == before)
for i in range(5):
    rc, _, err = submit('anon', {'email': 'spam@example.com', 'name': 'Spam %d' % i})
    assert rc == 0, err
rc, out, err = submit('anon', {'email': 'spam@example.com'})
check('szósty raz z tego samego adresu w godzinę: limit', rc != 0 and 'rate_limited' in err, err)
check('pracownik nie widzi zapytań', count('w1', 'select count(*) from public.inquiries') == 0)
check('właściciel widzi zapytania', count('owner', 'select count(*) from public.inquiries') == 6)
check('właściciel zapisuje wycenę', count('owner', """with u as (update public.inquiries set status='quoted', reply='{"quotes":{"photographer":900},"message":"ok"}'::jsonb
  where lower(email)='anna@example.com' returning 1) select count(*) from u""") == 1)
check('pracownik nie zmieni zapytania', count('w1', "with u as (update public.inquiries set status='declined' returning 1) select count(*) from u") == 0)

print('Z zapytania do sesji')
INQ = run('postgres', "select id from public.inquiries where lower(email)='anna@example.com'")[1]
sess = json.dumps({'title': 'Wesele – Anna Nowak', 'client': 'Anna Nowak', 'date': '2027-06-05', 'time': '15:00', 'location': 'Kraków',
                   'notes': 'Goście: 80', 'slots': {'photographer': {'n': 2, 'rate': 450}, 'photobooth': {'n': 1, 'rate': 0}}})
denied('pracownik nie utworzy sesji z zapytania', 'w1', "select public.create_session_from_inquiry('%s', '%s'::jsonb);" % (INQ, sess), 'not_owner')
denied('klient nie utworzy sesji z zapytania', 'anon', "select public.create_session_from_inquiry('%s', '%s'::jsonb);" % (INQ, sess), 'permission denied')
sid = allowed('właściciel tworzy sesję z zapytania', 'owner', "select public.create_session_from_inquiry('%s', '%s'::jsonb);" % (INQ, sess))
st = run('postgres', "select status || '|' || coalesce(session_id::text,'') from public.inquiries where id='%s'" % INQ)[1]
check('zapytanie oznaczone jako zarezerwowane i powiązane z sesją', st == 'booked|' + sid, st)
check('sesja ma 2 fotografów po 450 zł', run('postgres', "select (slots->'photographer'->>'n') || 'x' || (slots->'photographer'->>'rate') from public.sessions where id='%s'" % sid)[1] == '2x450')
check('pracownik od razu widzi nową sesję', count('w1', "select count(*) from public.sessions where id='%s'" % sid) == 1)
denied('nieznane zapytanie: błąd', 'owner', "select public.create_session_from_inquiry('99999999-0000-0000-0000-000000000000', '%s'::jsonb);" % sess, 'inquiry_not_found')

print('Zmiana adresu właściciela po fakcie')
run('postgres', "update public.app_config set owner_email = 'ktos@example.com'")
run('stranger', 'select public.ensure_profile();')
check('nowy właściciel dostaje dostęp po kolejnym logowaniu', run('postgres', "select role || '/' || approved from public.profiles where id='%s'" % U['stranger'][0])[1] == 'owner/true')
run('postgres', "update public.app_config set owner_email = 'owner@example.com'")

print('\nWynik: %d zaliczonych, %d niezaliczonych' % (passed, failed))
sys.exit(1 if failed else 0)
