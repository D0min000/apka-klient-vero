// Zastępczy backend do testów lokalnych. Udaje Supabase (logowanie Google, REST do bazy, funkcję send-quote)
// na PRAWDZIWYM Postgresie z tests/supabase-stub.sql + supabase/schema.sql, i udaje serwer SMTP Gmaila.
// Serwuje też pliki strony. Uruchom: node tests/mock-backend.mjs  (port 8787)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import tls from 'node:tls';
import crypto from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const PORT = Number(process.env.PORT || 8787);
const SMTP_PORT = Number(process.env.SMTP_PORT || 8465);
const PSQL = ['-h', '/tmp/pg', '-p', '5433', '-U', 'postgres', '-d', 'vero_test', '-X', '-q', '-At', '-v', 'ON_ERROR_STOP=1'];
const ANON = 'anon-key';
const SERVICE = 'service-key';
const GMAIL_USER = 'vero.studiokontakt@gmail.com';
const GMAIL_PASS_SPACED = 'abcd efgh ijkl mnop';

const IDENT = {
  owner: { id: '00000000-0000-0000-0000-0000000000a1', email: 'owner@example.com', name: 'Wiktoria Właścicielka' },
  ola: { id: '00000000-0000-0000-0000-0000000000b1', email: 'ola@example.com', name: 'Ola Fotograf' },
  pawel: { id: '00000000-0000-0000-0000-0000000000b2', email: 'pawel@example.com', name: 'Paweł Filmowiec' },
  kasia: { id: '00000000-0000-0000-0000-0000000000b3', email: 'kasia@example.com', name: 'Kasia Budka' },
};

// ---------- Postgres ----------
function runSql(role, user, sql) {
  let pre = '';
  if (role === 'anon') pre = 'set local role anon;\n';
  else if (role === 'service') pre = 'set local role service_role;\n';
  else if (role === 'authenticated') {
    const claims = JSON.stringify({ sub: user.id, email: user.email, role: 'authenticated', user_metadata: { full_name: user.name } });
    pre = `set local role authenticated;\nselect set_config('request.jwt.claims', '${claims.replace(/'/g, "''")}', true) \\gset\n`;
  }
  sql = sql.trim();
  if (!sql.endsWith(';')) sql += ';';
  const script = `\\set VERBOSITY verbose\nbegin;\n${pre}${sql}\ncommit;\n`;
  return new Promise((resolve) => {
    const p = spawn('psql', PSQL, { env: { ...process.env, PGCLIENTENCODING: 'UTF8' } });
    let out = '', err = '';
    p.stdout.on('data', (d) => (out += d));
    p.stderr.on('data', (d) => (err += d));
    p.on('close', (rc) => resolve({ rc, out: out.trim(), err: err.trim() }));
    p.stdin.end(script);
  });
}
const admin = (sql) => runSql('admin', null, sql);

const IDENT_RE = /^[a-z_][a-z0-9_]*$/;
const lit = (v) => {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (typeof v === 'object') return jsonLit(v);
  return "'" + String(v).replace(/'/g, "''") + "'";
};
function jsonLit(obj) {
  const s = JSON.stringify(obj);
  if (s.includes('$vj$')) throw new HttpError(400, 'P0001', 'bad body');
  return `$vj$${s}$vj$::jsonb`;
}
class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

function filters(params, alias) {
  const parts = [];
  for (const [k, v] of params) {
    if (['select', 'order', 'limit', 'offset', 'columns'].includes(k)) continue;
    if (!IDENT_RE.test(k)) throw new HttpError(400, 'PGRST100', 'bad column ' + k);
    const col = `${alias}"${k}"`;
    let m;
    if ((m = /^eq\.(.*)$/s.exec(v))) parts.push(`${col}::text = ${lit(m[1])}`);
    else if ((m = /^in\.\((.*)\)$/s.exec(v))) parts.push(`${col}::text in (${m[1].split(',').map((x) => lit(x.replace(/^"|"$/g, ''))).join(',')})`);
    else if (v === 'is.null') parts.push(`${col} is null`);
    else throw new HttpError(400, 'PGRST100', 'unsupported filter ' + k + '=' + v);
  }
  return parts.length ? ' where ' + parts.join(' and ') : '';
}

const RPC_STYLE = { ensure_profile: 'composite', submit_inquiry: 'scalar', create_session_from_inquiry: 'scalar', owner_people: 'set', set_approved: 'void' };

// ---------- logowanie (atrapa GoTrue) ----------
const tokens = new Map(); // access -> {user, exp}
const refreshes = new Map(); // refresh -> user
let nextLogin = 'owner';
let tokenTtlMs = 3600e3;

async function ensureAuthUser(u) {
  await admin(`insert into auth.users (id, email) values ('${u.id}', '${u.email}') on conflict (id) do nothing;`);
}
function issue(user) {
  const at = 'at.' + crypto.randomUUID();
  const rt = 'rt.' + crypto.randomUUID();
  tokens.set(at, { user, exp: Date.now() + tokenTtlMs });
  refreshes.set(rt, user);
  return { at, rt, expiresAt: Math.floor((Date.now() + tokenTtlMs) / 1000) };
}
function userJson(u) {
  return { id: u.id, email: u.email, aud: 'authenticated', role: 'authenticated', app_metadata: { provider: 'google' }, user_metadata: { full_name: u.name, avatar_url: null } };
}
function who(req) {
  const bearer = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '');
  const apikey = req.headers['apikey'] || '';
  if (bearer === SERVICE || (!bearer && apikey === SERVICE)) return { role: 'service' };
  if (bearer && bearer !== ANON) {
    const t = tokens.get(bearer);
    if (!t) throw new HttpError(401, 'PGRST301', 'JWT invalid');
    if (t.exp < Date.now()) throw new HttpError(401, 'PGRST301', 'JWT expired');
    return { role: 'authenticated', user: t.user };
  }
  if (apikey === ANON || bearer === ANON) return { role: 'anon' };
  throw new HttpError(401, 'PGRST301', 'No API key found in request');
}

// ---------- REST (atrapa PostgREST) ----------
async function rest(req, url, body) {
  const ctx = who(req);
  const rpc = /^\/rest\/v1\/rpc\/([a-z_]+)$/.exec(url.pathname);
  const prefer = String(req.headers['prefer'] || '');
  const wantRows = prefer.includes('return=representation');
  let sql;
  let status = 200;
  let useRows = true;
  if (rpc) {
    const fn = rpc[1];
    const style = RPC_STYLE[fn];
    if (!style) throw new HttpError(404, 'PGRST202', 'function not found: ' + fn);
    const args = Object.entries(body || {}).map(([k, v]) => {
      if (!IDENT_RE.test(k)) throw new HttpError(400, 'PGRST100', 'bad arg');
      return `${k} => ${lit(v)}`;
    }).join(', ');
    if (style === 'composite') sql = `select to_jsonb(f) from public.${fn}(${args}) f;`;
    else if (style === 'scalar') sql = `select to_jsonb(public.${fn}(${args}));`;
    else if (style === 'set') sql = `select coalesce(jsonb_agg(to_jsonb(f)), '[]'::jsonb) from public.${fn}(${args}) f;`;
    else { sql = `select public.${fn}(${args});`; useRows = false; status = 204; }
  } else {
    const m = /^\/rest\/v1\/([a-z_]+)$/.exec(url.pathname);
    if (!m) throw new HttpError(404, 'PGRST125', 'not found');
    const table = m[1];
    const P = url.searchParams;
    if (req.method === 'GET') {
      const sel = P.get('select') || '*';
      const cols = sel === '*' ? '*' : sel.split(',').map((c) => { if (!IDENT_RE.test(c)) throw new HttpError(400, 'PGRST100', 'bad select'); return `"${c}"`; }).join(',');
      let order = '';
      if (P.get('order')) {
        order = ' order by ' + P.get('order').split(',').map((o) => {
          const [c, d] = o.split('.');
          if (!IDENT_RE.test(c)) throw new HttpError(400, 'PGRST100', 'bad order');
          return `"${c}" ${d === 'desc' ? 'desc' : 'asc'}`;
        }).join(',');
      }
      const limit = P.get('limit') ? ` limit ${parseInt(P.get('limit'), 10)}` : '';
      sql = `select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select ${cols} from public.${table}${filters(P, '')}${order}${limit}) t;`;
    } else if (req.method === 'POST') {
      const rows = Array.isArray(body) ? body : [body];
      const cols = Object.keys(rows[0]);
      for (const c of cols) if (!IDENT_RE.test(c)) throw new HttpError(400, 'PGRST100', 'bad column');
      const cl = cols.map((c) => `"${c}"`).join(',');
      sql = `with r as (insert into public.${table} (${cl}) select ${cl} from jsonb_populate_recordset(null::public.${table}, ${jsonLit(rows)}) returning *) select coalesce(jsonb_agg(to_jsonb(r)), '[]'::jsonb) from r;`;
      status = 201;
    } else if (req.method === 'PATCH') {
      const cols = Object.keys(body);
      for (const c of cols) if (!IDENT_RE.test(c)) throw new HttpError(400, 'PGRST100', 'bad column');
      const set = cols.map((c) => `"${c}" = x."${c}"`).join(', ');
      sql = `with r as (update public.${table} as t set ${set} from jsonb_populate_record(null::public.${table}, ${jsonLit(body)}) x${filters(P, 't.')} returning t.*) select coalesce(jsonb_agg(to_jsonb(r)), '[]'::jsonb) from r;`;
    } else if (req.method === 'DELETE') {
      sql = `with r as (delete from public.${table} as t${filters(P, 't.')} returning t.*) select coalesce(jsonb_agg(to_jsonb(r)), '[]'::jsonb) from r;`;
    } else throw new HttpError(405, 'PGRST117', 'method');
  }
  const r = await runSql(ctx.role, ctx.user, sql);
  if (r.rc !== 0) {
    const m = /ERROR:\s+([0-9A-Z]{5}):\s+(.*)/.exec(r.err);
    const code = m ? m[1] : 'XX000';
    const message = m ? m[2] : r.err;
    const st = code === '42501' ? (ctx.role === 'anon' ? 401 : 403) : code.startsWith('23') ? 409 : 400;
    throw new HttpError(st, code, message);
  }
  if (!useRows || (!rpc && !wantRows && req.method !== 'GET')) return { status: status === 200 ? 204 : status, text: '' };
  return { status: req.method === 'POST' && !rpc ? 201 : 200, text: r.out };
}

// ---------- Deno + funkcja send-quote ----------
function adapt(sock) {
  const queue = [];
  let waiter = null;
  let ended = false;
  const wake = () => { if (waiter) { const w = waiter; waiter = null; w(); } };
  sock.on('data', (d) => { queue.push(d); wake(); });
  sock.on('end', () => { ended = true; wake(); });
  sock.on('error', () => { ended = true; wake(); });
  sock.on('close', () => { ended = true; wake(); });
  return {
    async read(p) {
      while (!queue.length) { if (ended) return null; await new Promise((r) => (waiter = r)); }
      const d = queue.shift();
      const n = Math.min(d.length, p.length);
      p.set(d.subarray(0, n));
      if (n < d.length) queue.unshift(d.subarray(n));
      return n;
    },
    write(p) { return new Promise((res, rej) => sock.write(p, (e) => (e ? rej(e) : res(p.length)))); },
    close() { sock.end(); },
  };
}
let handler = null;
globalThis.Deno = {
  env: { get: (k) => process.env[k] },
  serve: (h) => { handler = h; },
  connectTls: ({ hostname, port }) => new Promise((resolve, reject) => {
    const s = tls.connect({ host: hostname, port, rejectUnauthorized: false }, () => resolve(adapt(s)));
    s.once('error', reject);
  }),
};
Object.assign(process.env, {
  SUPABASE_URL: `http://127.0.0.1:${PORT}`,
  SUPABASE_SERVICE_ROLE_KEY: SERVICE,
  GMAIL_USER,
  GMAIL_APP_PASSWORD: GMAIL_PASS_SPACED,
  SMTP_HOST: '127.0.0.1',
  SMTP_PORT: String(SMTP_PORT),
});
await import(pathToFileURL(path.join(ROOT, 'supabase/functions/send-quote/index.ts')).href);
if (!handler) throw new Error('funkcja nie zarejestrowała handlera');

// ---------- fałszywy SMTP Gmaila ----------
const TMP = path.join(HERE, '.tmp');
fs.mkdirSync(TMP, { recursive: true });
if (!fs.existsSync(path.join(TMP, 'cert.pem'))) {
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', path.join(TMP, 'key.pem'), '-out', path.join(TMP, 'cert.pem'), '-days', '3', '-subj', '/CN=localhost'], { stdio: 'ignore' });
}
let mails = [];
let smtpMode = 'ok';
const smtpServer = tls.createServer({ key: fs.readFileSync(path.join(TMP, 'key.pem')), cert: fs.readFileSync(path.join(TMP, 'cert.pem')) }, (sock) => {
  if (smtpMode === 'down') { sock.destroy(); return; }
  let buf = '';
  let mode = 'cmd';
  let authStage = 0;
  let user = '';
  let cur = { from: '', to: [], data: [] };
  const w = (s) => sock.write(s + '\r\n');
  w('220 fake-gmail ESMTP ready');
  sock.on('error', () => {});
  sock.on('data', (d) => {
    buf += d.toString('utf8');
    let i;
    while ((i = buf.indexOf('\r\n')) !== -1) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 2);
      if (mode === 'data') {
        if (line === '.') {
          mails.push({ from: cur.from, to: cur.to, raw: cur.data.join('\r\n') + '\r\n' });
          cur = { from: '', to: [], data: [] };
          mode = 'cmd';
          w('250 2.0.0 OK queued');
        } else cur.data.push(line.startsWith('..') ? line.slice(1) : line);
        continue;
      }
      if (authStage === 1) { user = Buffer.from(line, 'base64').toString(); authStage = 2; w('334 UGFzc3dvcmQ6'); continue; }
      if (authStage === 2) {
        authStage = 0;
        const pass = Buffer.from(line, 'base64').toString();
        if (smtpMode === 'auth_fail' || user !== GMAIL_USER || pass !== GMAIL_PASS_SPACED.replace(/ /g, '')) w('535 5.7.8 Username and Password not accepted');
        else w('235 2.7.0 Accepted');
        continue;
      }
      const up = line.toUpperCase();
      if (up.startsWith('EHLO')) { sock.write('250-fake-gmail\r\n250 AUTH LOGIN PLAIN\r\n'); }
      else if (up === 'AUTH LOGIN') { authStage = 1; w('334 VXNlcm5hbWU6'); }
      else if (up.startsWith('MAIL FROM:')) { cur.from = line.slice(10); w('250 2.1.0 OK'); }
      else if (up.startsWith('RCPT TO:')) {
        if (smtpMode === 'rcpt_reject') w('550 5.1.1 The email account that you tried to reach does not exist');
        else { cur.to.push(line.slice(8)); w('250 2.1.5 OK'); }
      }
      else if (up === 'DATA') { mode = 'data'; w('354 Go ahead'); }
      else if (up === 'QUIT') { w('221 2.0.0 closing'); sock.end(); }
      else w('500 5.5.1 unrecognized');
    }
  });
});
smtpServer.listen(SMTP_PORT, '127.0.0.1');

// ---------- HTTP ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.svg': 'image/svg+xml' };
const readBody = (req) => new Promise((resolve) => { const c = []; req.on('data', (d) => c.push(d)); req.on('end', () => resolve(Buffer.concat(c).toString('utf8'))); });
const send = (res, status, text, headers = {}) => { res.writeHead(status, { 'Access-Control-Allow-Origin': '*', ...headers }); res.end(text); };
const sendJson = (res, status, obj) => send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json' });

const CONFIG_JS = `window.VERO_CONFIG = { SUPABASE_URL: 'http://127.0.0.1:${PORT}', SUPABASE_ANON_KEY: '${ANON}', CONTACT: { email: 'vero.studiokontakt@gmail.com', phone: '888 420 722', instagram: '' } };`;

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
    const p = url.pathname;
    if (req.method === 'OPTIONS' && (p.startsWith('/rest/') || p.startsWith('/auth/'))) {
      return send(res, 204, '', { 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' });
    }
    // sterowanie testami
    if (p === '/mock/next-login') { nextLogin = JSON.parse(await readBody(req)).user; return sendJson(res, 200, { ok: true }); }
    if (p === '/mock/expire') { for (const t of tokens.values()) t.exp = 0; return sendJson(res, 200, { ok: true }); }
    if (p === '/mock/mail') return sendJson(res, 200, mails);
    if (p === '/mock/smtp') { smtpMode = JSON.parse(await readBody(req)).mode; return sendJson(res, 200, { ok: true }); }
    if (p === '/mock/sql') { const r = await admin(JSON.parse(await readBody(req)).sql); return sendJson(res, 200, r); }
    if (p === '/mock/reset') {
      await admin('truncate public.payments, public.signups, public.inquiries, public.sessions, public.profiles cascade; delete from auth.users; update public.app_config set owner_email = \'owner@example.com\';');
      tokens.clear(); refreshes.clear(); mails = []; smtpMode = 'ok'; nextLogin = 'owner'; tokenTtlMs = 3600e3;
      return sendJson(res, 200, { ok: true });
    }
    // logowanie
    if (p === '/auth/v1/authorize') {
      if (url.searchParams.get('provider') !== 'google') return sendJson(res, 400, { msg: 'provider not enabled' });
      const u = IDENT[nextLogin];
      await ensureAuthUser(u);
      const t = issue(u);
      const back = url.searchParams.get('redirect_to');
      const frag = `access_token=${t.at}&expires_in=${Math.floor(tokenTtlMs / 1000)}&expires_at=${t.expiresAt}&refresh_token=${t.rt}&token_type=bearer&provider_token=x`;
      return send(res, 302, '', { Location: back + '#' + frag });
    }
    if (p === '/auth/v1/user') {
      const bearer = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '');
      const t = tokens.get(bearer);
      if (!t || t.exp < Date.now()) return sendJson(res, 401, { code: 401, msg: 'invalid JWT' });
      return sendJson(res, 200, userJson(t.user));
    }
    if (p === '/auth/v1/token') {
      const b = JSON.parse((await readBody(req)) || '{}');
      const u = refreshes.get(b.refresh_token);
      if (!u) return sendJson(res, 400, { error: 'invalid_grant', error_description: 'Invalid Refresh Token' });
      refreshes.delete(b.refresh_token);
      const t = issue(u);
      return sendJson(res, 200, { access_token: t.at, token_type: 'bearer', expires_in: Math.floor(tokenTtlMs / 1000), expires_at: t.expiresAt, refresh_token: t.rt, user: userJson(u) });
    }
    if (p === '/auth/v1/logout') {
      const bearer = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '');
      tokens.delete(bearer);
      return send(res, 204, '');
    }
    // funkcja maili
    if (p === '/functions/v1/send-quote') {
      const body = req.method === 'POST' ? await readBody(req) : undefined;
      const headers = {};
      for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers[k] = v;
      const r = await handler(new Request('http://localhost' + p, { method: req.method, headers, body }));
      const out = {};
      r.headers.forEach((v, k) => (out[k] = v));
      return send(res, r.status, await r.text(), out);
    }
    // REST
    if (p.startsWith('/rest/v1/')) {
      const raw = ['POST', 'PATCH'].includes(req.method) ? await readBody(req) : '';
      let body = null;
      if (raw) { try { body = JSON.parse(raw); } catch { throw new HttpError(400, 'PGRST102', 'bad json'); } }
      const r = await rest(req, url, body);
      return send(res, r.status, r.text, { 'Content-Type': 'application/json' });
    }
    // pliki strony
    if (p === '/config.js') return send(res, 200, CONFIG_JS, { 'Content-Type': MIME['.js'] });
    let f = path.normalize(path.join(ROOT, decodeURIComponent(p)));
    if (!f.startsWith(ROOT) || f.startsWith(path.join(ROOT, 'tests')) || f.startsWith(path.join(ROOT, 'supabase'))) return send(res, 404, 'not found');
    if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
    if (!fs.existsSync(f)) return send(res, 404, 'not found');
    return send(res, 200, fs.readFileSync(f), { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  } catch (e) {
    if (e instanceof HttpError) return sendJson(res, e.status, { code: e.code, message: e.message, details: null, hint: null });
    console.error(e);
    return sendJson(res, 500, { code: 'XX000', message: String(e && e.message || e) });
  }
});
server.listen(PORT, '127.0.0.1', () => console.log('READY ' + PORT));
