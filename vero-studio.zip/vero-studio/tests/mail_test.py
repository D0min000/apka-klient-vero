#!/usr/bin/env python3
"""Test funkcji wysyłającej maile: kto może jej użyć, co dokładnie wychodzi, co się dzieje przy awariach poczty.
Wymaga działającego: node tests/mock-backend.mjs (udaje Supabase i serwer SMTP Gmaila)."""
import email
import email.policy
import http.client
import json
import sys
import urllib.parse

HOST, PORT = '127.0.0.1', 8787
ANON = 'anon-key'
passed = failed = 0


def http_call(method, path, body=None, headers=None, raw=False):
    c = http.client.HTTPConnection(HOST, PORT, timeout=20)
    h = {'apikey': ANON}
    h.update(headers or {})
    data = None
    if body is not None:
        data = body if isinstance(body, (bytes, str)) else json.dumps(body)
        h.setdefault('Content-Type', 'application/json')
    c.request(method, path, body=data.encode() if isinstance(data, str) else data, headers=h)
    r = c.getresponse()
    text = r.read().decode('utf-8')
    hdrs = dict(r.getheaders())
    c.close()
    if raw:
        return r.status, text, hdrs
    try:
        return r.status, (json.loads(text) if text else None), hdrs
    except ValueError:
        return r.status, text, hdrs


def check(name, cond, detail=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ' + name)
    else:
        failed += 1
        print('  FAIL ' + name + (' -> ' + str(detail) if detail else ''))


def login(user):
    http_call('POST', '/mock/next-login', {'user': user})
    st, _, hdrs = http_call('GET', '/auth/v1/authorize?provider=google&redirect_to=' + urllib.parse.quote('http://localhost/panel/'), raw=True)
    assert st == 302, st
    frag = urllib.parse.parse_qs(urllib.parse.urlparse(hdrs['Location']).fragment)
    tok = frag['access_token'][0]
    st, prof, _ = http_call('POST', '/rest/v1/rpc/ensure_profile', {}, {'Authorization': 'Bearer ' + tok})
    assert st == 200, (st, prof)
    return tok


def auth(tok):
    return {'Authorization': 'Bearer ' + tok}


def make_inquiry(email_addr='anna@example.com', name='Anna Nowak'):
    st, r, _ = http_call('POST', '/rest/v1/rpc/submit_inquiry', {'p': {
        'name': name, 'email': email_addr, 'phone': '600100200', 'category': 'wesele', 'date': '2027-06-05', 'start': '15:00',
        'hours': '7-8 godz.', 'location': 'Kraków, Dwór Zielony', 'guests': '80', 'services': ['photographer', 'photobooth'],
        'counts': {'photographer': 2}, 'details': 'Reportaż i fotobudka'}})
    assert st == 200, (st, r)
    return r


def save_quote(owner_tok, inq):
    st, r, _ = http_call('PATCH', '/rest/v1/inquiries?id=eq.' + inq, {
        'status': 'quoted',
        'reply': {'quotes': {'photographer': 900, 'photobooth': 800}, 'message': 'Chętnie zrealizujemy Wasz termin.', 'at': '2026-11-21T10:00:00Z', 'sentAt': None}},
        {**auth(owner_tok), 'Prefer': 'return=representation'})
    assert st == 200 and len(r) == 1, (st, r)


def sql(q):
    st, r, _ = http_call('POST', '/mock/sql', {'sql': q})
    return r['out']


def send(tok, payload):
    return http_call('POST', '/functions/v1/send-quote', payload, auth(tok) if tok else {})


def mails():
    return http_call('GET', '/mock/mail')[1]


BODY = ('Cześć Anno,\n\ndziękujemy za zapytanie o wesele (5 czerwca 2027, Kraków).\n\nNasza wycena:\n- Fotograf (2 osoby): 900,00 zł\n'
        '- Fotobudka: 800,00 zł\nRazem: 1 700,00 zł\n\n.Ta linia zaczyna się od kropki, żeby sprawdzić ochronę protokołu SMTP.\n'
        'Bardzo długa linia: ' + ('zażółć gęślą jaźń ' * 20) + '\n\nPozdrawiamy,\nZespół Vero Studio')
SUBJ = 'Vero Studio – wycena: Wesele, 5 czerwca 2027'

http_call('POST', '/mock/reset')
owner = login('owner')
ola = login('ola')          # czeka na zatwierdzenie
pawel = login('pawel')      # zostanie zatwierdzony, ale to nie właściciel
oid = sql("select id from public.profiles where email='owner@example.com'")
http_call('POST', '/rest/v1/rpc/set_approved', {'p_user': '00000000-0000-0000-0000-0000000000b2', 'p_approved': True}, auth(owner))
inq = make_inquiry()

print('Dostęp do funkcji')
st, _, h = http_call('OPTIONS', '/functions/v1/send-quote', raw=True)
check('preflight z przeglądarki przechodzi (CORS)', st in (200, 204))
st, r, _ = http_call('POST', '/functions/v1/send-quote', {'inquiryId': inq, 'subject': SUBJ, 'body': BODY}, raw=False)
check('bez logowania: 401', st == 401 and r['error'] == 'not_signed_in', (st, r))
st, r, _ = send('at.nieprawdziwy', {'inquiryId': inq, 'subject': SUBJ, 'body': BODY})
check('z fałszywym tokenem: 401', st == 401, (st, r))
st, r, _ = send(ola, {'inquiryId': inq, 'subject': SUBJ, 'body': BODY})
check('pracownik czekający na zatwierdzenie: 403', st == 403 and r['error'] == 'not_owner', (st, r))
st, r, _ = send(pawel, {'inquiryId': inq, 'subject': SUBJ, 'body': BODY})
check('zatwierdzony pracownik: 403', st == 403 and r['error'] == 'not_owner', (st, r))
check('żaden z tych prób nie wysłał maila', len(mails()) == 0)

print('Walidacja')
st, r, _ = send(owner, {'inquiryId': inq, 'subject': SUBJ, 'body': BODY})
check('zapytanie bez zapisanej wyceny: 409', st == 409 and r['error'] == 'no_quote_saved', (st, r))
save_quote(owner, inq)
st, r, _ = send(owner, {'inquiryId': 'nie-uuid', 'subject': SUBJ, 'body': BODY})
check('zły identyfikator: 400', st == 400 and r['error'] == 'bad_inquiry', (st, r))
st, r, _ = send(owner, {'inquiryId': '99999999-0000-0000-0000-000000000000', 'subject': SUBJ, 'body': BODY})
check('nieistniejące zapytanie: 404', st == 404, (st, r))
st, r, _ = send(owner, {'inquiryId': inq, 'subject': '   ', 'body': BODY})
check('pusty temat: 400', st == 400 and r['error'] == 'bad_subject', (st, r))
st, r, _ = send(owner, {'inquiryId': inq, 'subject': SUBJ, 'body': ''})
check('pusta treść: 400', st == 400 and r['error'] == 'bad_body', (st, r))
sql("update public.inquiries set email='' where id='%s'" % inq)
st, r, _ = send(owner, {'inquiryId': inq, 'subject': SUBJ, 'body': BODY})
check('klient bez e-maila: 400', st == 400 and r['error'] == 'client_has_no_email', (st, r))
sql("update public.inquiries set email='anna@example.com' where id='%s'" % inq)
check('walidacja nie wysłała żadnego maila', len(mails()) == 0)

print('Wysyłka właściciela')
st, r, _ = send(owner, {'inquiryId': inq, 'subject': SUBJ, 'body': BODY, 'to': 'ktos-inny@example.com'})
check('właściciel: 200 i ok', st == 200 and r.get('ok') is True and r.get('saved') is True, (st, r))
ms = mails()
check('wyszedł dokładnie jeden mail', len(ms) == 1, len(ms))
m = ms[0]
msg = email.message_from_bytes(m['raw'].encode('utf-8'), policy=email.policy.default)
check('adresat to adres klienta z bazy, a nie ten z żądania', m['to'] == ['<anna@example.com>'], m['to'])
check('nadawca to konto Gmail studia', m['from'] == '<vero.studiokontakt@gmail.com>', m['from'])
check('nazwa nadawcy: Vero Studio', 'Vero Studio' in str(msg['From']) and 'vero.studiokontakt@gmail.com' in str(msg['From']), msg['From'])
check('odpowiedź klienta wraca do studia (Reply-To)', 'vero.studiokontakt@gmail.com' in str(msg['Reply-To']))
check('temat z polskimi znakami i myślnikiem czytelny', str(msg['Subject']) == SUBJ, msg['Subject'])
text = msg.get_content().replace('\r\n', '\n').rstrip('\n')
check('treść identyczna znak w znak (polskie litery, kropka na początku linii, długa linia)', text == BODY, repr(text[:200]))
check('nagłówki kodowania poprawne', msg['Content-Type'].startswith('text/plain') and 'utf-8' in msg['Content-Type'].lower())
rep = json.loads(sql("select reply::text from public.inquiries where id='%s'" % inq))
check('w bazie zapisano czas wysłania i adresata', rep.get('sentTo') == 'anna@example.com' and rep.get('sentAt'), rep)
check('wycena w bazie nienaruszona', rep['quotes'] == {'photographer': 900, 'photobooth': 800}, rep)

print('Ochrona przed nadużyciem')
http_call('POST', '/mock/reset')
owner = login('owner'); inq = make_inquiry(); save_quote(owner, inq)
st, r, _ = send(owner, {'inquiryId': inq, 'subject': 'Hej\r\nBcc: ofiara@example.com\r\nX-Evil: 1', 'body': 'Test\r\n.\r\nQUIT\r\nMAIL FROM:<x@y.z>'})
ms = mails()
check('próba wstrzyknięcia nagłówków przechodzi jako zwykły tekst', st == 200 and len(ms) == 1, (st, r))
msg = email.message_from_bytes(ms[0]['raw'].encode('utf-8'), policy=email.policy.default)
check('brak dodatkowego nagłówka Bcc', msg['Bcc'] is None and msg['X-Evil'] is None, list(msg.keys()))
check('temat zlał się do jednej linii', 'ofiara@example.com' in str(msg['Subject']) and '\n' not in str(msg['Subject']).strip())
check('wiadomość z "." i komendami SMTP w treści dotarła w całości jako jeden mail', len(ms) == 1 and ms[0]['to'] == ['<anna@example.com>'])

print('Awarie poczty')
for mode, err, label in [('auth_fail', 'smtp_auth', 'Gmail odrzuca hasło aplikacji'), ('rcpt_reject', 'smtp_recipient_rejected', 'Gmail odrzuca adres klienta'), ('down', 'smtp_unreachable', 'serwer poczty niedostępny')]:
    http_call('POST', '/mock/reset')
    owner = login('owner'); inq = make_inquiry(); save_quote(owner, inq)
    http_call('POST', '/mock/smtp', {'mode': mode})
    st, r, _ = send(owner, {'inquiryId': inq, 'subject': SUBJ, 'body': BODY})
    check(label + ': 502 ' + err, st == 502 and r['error'] == err, (st, r))
    rep = json.loads(sql("select reply::text from public.inquiries where id='%s'" % inq))
    check('  i w bazie nie ma fałszywego "wysłano"', not rep.get('sentAt'), rep)
    check('  i nic nie wyszło', len(mails()) == 0)
    http_call('POST', '/mock/smtp', {'mode': 'ok'})
    st, r, _ = send(owner, {'inquiryId': inq, 'subject': SUBJ, 'body': BODY})
    check('  po naprawie awarii ponowna wysyłka działa', st == 200 and len(mails()) == 1, (st, r))

print('\nWynik: %d zaliczonych, %d niezaliczonych' % (passed, failed))
sys.exit(1 if failed else 0)
