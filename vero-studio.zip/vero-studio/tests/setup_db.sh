#!/usr/bin/env bash
# Tworzy lokalną bazę testową (UTF-8, jak w Supabase) z atrapą Supabase i schematem aplikacji.
set -euo pipefail
export PGCLIENTENCODING=UTF8
P="psql -h /tmp/pg -p 5433 -U postgres -v ON_ERROR_STOP=1 -q"
$P -d postgres -c "drop database if exists vero_test" -c "create database vero_test encoding 'UTF8' lc_collate 'C' lc_ctype 'C' template template0"
$P -d vero_test -f "$(dirname "$0")/supabase-stub.sql"
sed "s/WPISZ_TU_SWOJ_ADRES@gmail.com/owner@example.com/" "$(dirname "$0")/../supabase/schema.sql" > /tmp/pg/schema_test.sql
$P -d vero_test -f /tmp/pg/schema_test.sql 2>&1 | grep -v NOTICE || true
echo DB_READY
