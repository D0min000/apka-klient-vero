#!/usr/bin/env python3
"""Test całej aplikacji w prawdziwej przeglądarce (Chromium) na atrapie Supabase: node tests/mock-backend.mjs"""
import email, email.policy, json, re, sys, time, urllib.request
from playwright.sync_api import sync_playwright, expect

BASE = 'http://127.0.0.1:8787'
passed = failed = 0

def api(path, body=None):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={'Content-Type': 'application/json'}, method='POST' if body is not None else 'GET')
    return json.loads(urllib.request.urlopen(req).read().decode() or 'null')

def sql(q):
    return api('/mock/sql', {'sql': q})['out']

def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('  ok   ' + name)
    else: failed += 1; print('  FAIL ' + name + (' -> ' + str(detail) if detail else ''))

def tab(page, name):
    page.locator('button[role=tab]', has_text=name).first.click()

def login(browser, user, path='/panel/'):
    ctx = browser.new_context(viewport={'width': 420, 'height': 900}, locale='pl-PL')
    ctx.route(re.compile(r'https://fonts\.(googleapis|gstatic)\.com/.*'), lambda r: r.abort())
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.errors = errors
    api('/mock/next-login', {'user': user})
    page.goto(BASE + path)
    page.locator('#login').click()
    return ctx, page

def text_of(page):
    return page.locator('#app').inner_text()

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    api('/mock/reset', {})

    print('Logowanie i zatwierdzanie')
    ctxO = browser.new_context(); ctxO.close()
    ctxO, owner = login(browser, 'owner')
    owner.get_by_text('Brak sesji').wait_for()
    check('właściciel po zalogowaniu widzi pusty grafik', 'Brak sesji' in text_of(owner))
    check('właściciel widzi zakładki Zapytania, Rozliczenia, Ekipa', all(t in text_of(owner) for t in ['Zapytania', 'Rozliczenia', 'Ekipa']))
    check('przełącznik Właściciel/Pracownik jest', owner.get_by_role('button', name='Pracownik').count() == 1)

    ctxA, ola = login(browser, 'ola')
    ola.get_by_text('Konto czeka na zatwierdzenie').wait_for()
    check('nowy pracownik widzi ekran oczekiwania, nie grafik', 'czeka na zatwierdzenie' in text_of(ola) and 'Sesje' not in ola.locator('.tabs').all_inner_texts())
    check('ekran oczekiwania podaje e-mail', 'ola@example.com' in text_of(ola), text_of(ola))

    owner.reload(); owner.locator('#app .tabs').wait_for(); tab(owner, 'Ekipa')
    owner.get_by_text('Czekają na zatwierdzenie').wait_for()
    row = owner.locator('.person-row', has_text='ola@example.com')
    check('właściciel widzi Olę w oczekujących', row.count() == 1)
    check('liczba oczekujących na zakładce', 'Ekipa (1)' in text_of(owner), owner.locator('.tabs').inner_text())
    row.get_by_role('button', name='Zatwierdź').click()
    owner.get_by_text('Ekipa (2)').wait_for()
    check('po zatwierdzeniu Ola jest w ekipie', owner.locator('.person-row', has_text='ola@example.com').get_by_text('zatwierdzony').count() == 1)

    ola.get_by_role('button', name='Sprawdź teraz').click()
    ola.locator('.stats').wait_for()
    check('Ola po zatwierdzeniu widzi grafik', 'Sesje' in ola.locator('.tabs').inner_text())
    check('Ola nie ma zakładek właściciela ani przełącznika', 'Ekipa' not in ola.locator('.tabs').inner_text() and 'Zapytania' not in ola.locator('.tabs').inner_text() and ola.get_by_role('button', name='Właściciel').count() == 0)

    print('Sesje i zapisy')
    owner.locator('button[role=tab]', has_text='Sesje').click()
    owner.get_by_role('button', name='+ Dodaj sesję').click()
    owner.fill('#f-title', 'Wesele Ani i Marka'); owner.fill('#f-client', 'Ania Kowalska'); owner.fill('#f-date', '2027-06-05'); owner.fill('#f-time', '15:00')
    owner.fill('#f-loc', 'Kraków, Dwór Zielony'); owner.fill('#f-notes', 'Reportaż + fotobudka')
    owner.fill('#f-n-photographer', '2'); owner.fill('#f-r-photographer', '400')
    owner.fill('#f-n-photobooth', '1'); owner.fill('#f-r-photobooth', '700')
    owner.fill('#f-n-videographer', '0')
    owner.get_by_role('button', name='Dodaj sesję').last.click()
    owner.get_by_text('Wesele Ani i Marka').wait_for()
    check('sesja pojawia się u właściciela', owner.locator('.sess', has_text='Wesele Ani i Marka').count() == 1)
    rows = json.loads(sql("select json_agg(row_to_json(s))::text from public.sessions s"))
    check('sesja zapisana w bazie z rolami i stawkami', len(rows) == 1 and rows[0]['slots']['photographer'] == {'n': 2, 'rate': 400} and rows[0]['event_date'] == '2027-06-05', rows)

    ola.reload(); ola.get_by_text('Wesele Ani i Marka').wait_for()
    check('Ola widzi nową sesję po odświeżeniu', True)
    card = ola.locator('.sess', has_text='Wesele Ani i Marka')
    card.locator('.role.photo').get_by_role('button', name='Biorę').click()
    card.locator('.role.photo .chip.me').wait_for()
    check('Ola zapisała się na fotografa', card.locator('.role.photo .chip.me').count() == 1)
    check('widzi swoją stawkę w złotych', '400' in card.locator('.role.photo').inner_text())
    check('zapis jest w bazie', sql("select count(*) from public.signups where role='photographer'") == '1', sql("select count(*) from public.signups"))
    owner.reload(); owner.get_by_text('Wesele Ani i Marka').wait_for()
    check('właściciel widzi Olę przy roli', 'Ola' in owner.locator('.sess .role.photo').inner_text(), owner.locator('.sess .role.photo').inner_text())

    # kolejka: Paweł i Kasia (zatwierdzeni przez bazę)
    ctxP, pawel = login(browser, 'pawel'); pawel.get_by_text('Konto czeka na zatwierdzenie').wait_for()
    ctxK, kasia = login(browser, 'kasia'); kasia.get_by_text('Konto czeka na zatwierdzenie').wait_for()
    sql("update public.profiles set approved=true where email in ('pawel@example.com','kasia@example.com')")
    pawel.get_by_role('button', name='Sprawdź teraz').click(); pawel.locator('.stats').wait_for()
    kasia.get_by_role('button', name='Sprawdź teraz').click(); kasia.locator('.stats').wait_for()
    pawel.locator('.sess .role.photo').get_by_role('button', name='Biorę').click(); pawel.locator('.sess .role.photo .chip.me').wait_for()
    time.sleep(0.4)
    kasia.reload(); kasia.get_by_text('Wesele Ani i Marka').wait_for()
    btn = kasia.locator('.sess .role.photo').get_by_role('button')
    check('przy pełnej obsadzie przycisk to „Do kolejki”', btn.inner_text() == 'Do kolejki', btn.inner_text())
    check('obsada 2/2 pokazuje „obsadzone”', 'obsadzone' in kasia.locator('.sess .role.photo').inner_text())
    btn.click(); kasia.locator('.sess .role.photo .chip.me').wait_for(state='detached') if False else None
    kasia.get_by_role('button', name='Rezygnuję').wait_for()
    check('Kasia jest w kolejce, nie w obsadzie', 'w kolejce' in kasia.locator('.sess .role.photo').inner_text())
    ola.reload(); ola.get_by_text('Wesele Ani i Marka').wait_for()
    ola.locator('.sess .role.photo').get_by_role('button', name='Rezygnuję').click()
    ola.get_by_role('button', name='Biorę').first.wait_for()
    kasia.reload(); kasia.get_by_text('Wesele Ani i Marka').wait_for()
    check('po rezygnacji Oli Kasia awansuje z kolejki', 'w kolejce' not in kasia.locator('.sess .role.photo').inner_text() and kasia.locator('.sess .role.photo .chip.me').count() == 1, kasia.locator('.sess .role.photo').inner_text())

    print('Rozliczenia')
    sid = sql("select id from public.sessions limit 1")
    sql("insert into public.sessions (title, client, event_date, start_time, location, slots) values ('Osiemnastka Zuzi','Zuza','2026-10-10','18:00','Łódź','{\"photographer\":{\"n\":1,\"rate\":300}}')")
    psid = sql("select id from public.sessions where title='Osiemnastka Zuzi'")
    sql("insert into public.signups (session_id, role, user_id) select '%s','photographer', id from public.profiles where email='ola@example.com'" % psid)
    owner.reload(); owner.locator('.tabs').wait_for(); tab(owner, 'Rozliczenia')
    owner.get_by_text('Osiemnastka Zuzi').wait_for()
    check('właściciel widzi kwotę do zapłaty 300 zł', '300' in owner.locator('.stat.hot').inner_text(), owner.locator('.stat.hot').inner_text())
    owner.get_by_role('button', name='Zapłacone').first.click()
    owner.locator('.pill.ok').first.wait_for()
    check('wypłata zapisana w bazie', sql("select amount from public.payments") in ('300', '300.00'), sql("select count(*) from public.payments"))
    ola.reload(); ola.locator('.tabs').wait_for(); tab(ola, 'Moje wypłaty')
    ola.get_by_text('Osiemnastka Zuzi').wait_for()
    check('Ola widzi, że dostała 300 zł', 'zapłacone' in ola.locator('.card.person').inner_text() and '300' in ola.locator('.stat.good').inner_text(), ola.locator('.stat.good').inner_text())
    ctxPay = pawel; tab(pawel, 'Moje wypłaty'); pawel.reload(); tab(pawel, 'Moje wypłaty')
    check('Paweł nie widzi cudzych wypłat', 'Osiemnastka Zuzi' not in text_of(pawel))
    owner.get_by_role('button', name='Cofnij').first.click()
    owner.get_by_role('button', name='Zapłacone').first.wait_for()
    for _ in range(20):
        if sql("select count(*) from public.payments") == '0': break
        time.sleep(0.15)
    check('cofnięcie wypłaty działa', sql("select count(*) from public.payments") == '0')

    print('Strona klienta')
    cctx = browser.new_context(viewport={'width': 400, 'height': 900}, locale='pl-PL')
    cctx.route(re.compile(r'https://fonts\.(googleapis|gstatic)\.com/.*'), lambda r: r.abort())
    c = cctx.new_page(); cerrs = []; c.on('pageerror', lambda e: cerrs.append(str(e)))
    c.goto(BASE + '/')
    check('strona klienta pokazuje ceny z widełkami', all(t in c.inner_text('body') for t in ['250–600 zł', '600–1100 zł', 'Wycena indywidualna']))
    check('strona klienta pokazuje kontakt', 'vero.studiokontakt@gmail.com' in c.inner_text('body') and '888 420 722' in c.inner_text('body'))
    check('widać opis zespołu', 'Młody, przyjazny zespół' in c.inner_text('body'))
    c.click('#submit'); check('pusty formularz: komunikat zamiast wysyłki', 'Wybierz rodzaj' in c.inner_text('#ferr'))
    check('nic nie wysłano do bazy', sql("select count(*) from public.inquiries") == '0')
    def fill_client(mail='anna@example.com', website=''):
        c.select_option('#f-cat', 'wesele'); c.fill('#f-date', '2027-06-05'); c.fill('#f-start', '15:00'); c.select_option('#f-hours', '7–8 godz.')
        c.fill('#f-guests', '80'); c.fill('#f-loc', 'Kraków, Dwór Zielony')
        c.check('#f-sv-photographer'); c.check('#f-sv-photobooth'); c.select_option('#f-count', '2')
        c.fill('#f-details', 'Reportaż, dużo ujęć z tańców. Zażółć gęślą jaźń.')
        c.fill('#f-name', 'Anna Nowak'); c.fill('#f-mail', mail); c.fill('#f-tel', '600100200'); c.check('#f-consent')
        if website: c.evaluate("v => document.getElementById('f-website').value = v", website)
    fill_client('zly-adres')
    c.click('#submit'); check('zły e-mail zatrzymany w przeglądarce', 'poprawny adres e-mail' in c.inner_text('#ferr'))
    c.fill('#f-mail', 'anna@example.com')
    check('orientacyjny koszt liczy 2 fotografów + fotobudkę', re.sub(r'\s', '', c.inner_text('#est')).startswith('Orientacyjnie:1100–2300zł'), c.inner_text('#est'))
    c.click('#submit'); c.locator('#done').wait_for(state='visible')
    check('klient widzi potwierdzenie wysłania', 'Zapytanie wysłane' in c.inner_text('#done'))
    row = json.loads(sql("select row_to_json(i)::text from public.inquiries i"))
    check('zapytanie w bazie ma komplet danych', row['name'] == 'Anna Nowak' and row['email'] == 'anna@example.com' and row['category'] == 'wesele' and row['guests'] == '80' and row['counts'] == {'photographer': 2} and sorted(row['services']) == ['photobooth', 'photographer'] and row['status'] == 'new' and row['source'] == 'form', row)
    check('polskie znaki dotarły', 'Zażółć gęślą jaźń' in row['details'])
    c.click('#again'); fill_client(website='http://spam.pl'); c.click('#submit'); c.locator('#done').wait_for(state='visible')
    check('bot z wypełnionym polem-pułapką nie tworzy zapytania', sql("select count(*) from public.inquiries") == '1')
    check('brak błędów JS na stronie klienta', not cerrs, cerrs)

    print('Zapytanie -> wycena -> mail -> rezerwacja')
    owner.reload(); owner.locator('.tabs').wait_for(); tab(owner, 'Zapytania')
    check('licznik nowych zapytań w zakładce', 'Zapytania (1)' in owner.locator('.tabs').inner_text(), owner.locator('.tabs').inner_text())
    owner.locator('.inq', has_text='Anna Nowak').click()
    owner.locator('#q-photographer').wait_for()
    check('szczegóły zapytania widoczne (2 fotografów)', '×2' in owner.locator('.panel').inner_text() and 'Dwór Zielony' in owner.locator('.panel').inner_text())
    owner.fill('#q-photographer', '900'); owner.fill('#q-photobooth', '800')
    owner.click('#q-save'); owner.locator('#m-send').wait_for()
    check('wycena zapisana, pojawia się sekcja maila', 'Razem:1700' in re.sub(r'\s', '', owner.locator('.panel').inner_text()))
    body = owner.input_value('#m-body')
    check('treść maila zawiera obie ceny i sumę', '900' in body and '800' in body and 'Razem:1700' in re.sub(r'\s', '', body) and '2 osoby' in body, body)
    owner.click('#m-send')
    check('przed wysłaniem jest prośba o potwierdzenie', 'Potwierdź wysłanie do anna@example.com' in owner.inner_text('#m-send'))
    check('jeszcze nic nie wyszło', len(api('/mock/mail')) == 0)
    owner.click('#m-send'); owner.locator('#m-sent').wait_for()
    mails = api('/mock/mail')
    check('wyszedł dokładnie jeden mail na adres klienta', len(mails) == 1 and mails[0]['to'] == ['<anna@example.com>'], mails)
    check('mail zawiera wycenę z polskimi znakami', 'dziękujemy za zapytanie' in email.message_from_bytes(mails[0]['raw'].encode(), policy=email.policy.default).get_content())
    check('w panelu widać „Wysłano”', owner.locator('#m-sent').count() == 1)
    check('status zapytania: wycenione', sql("select status from public.inquiries") == 'quoted')

    owner.click('#m-send'); owner.click('#m-send')  # ponowna wysyłka po potwierdzeniu
    time.sleep(0.8)
    check('ponowna wysyłka (po potwierdzeniu) działa', len(api('/mock/mail')) == 2)

    api('/mock/smtp', {'mode': 'auth_fail'})
    owner.click('#m-send'); owner.click('#m-send')
    owner.locator('#m-status', has_text='Gmail odrzucił logowanie').wait_for()
    check('błąd hasła aplikacji pokazuje czytelny komunikat', True)
    check('po błędzie nie dodano maila', len(api('/mock/mail')) == 2)
    api('/mock/smtp', {'mode': 'ok'})

    owner.click('#q-book')
    owner.fill('#f-time', '15:00')
    check('formularz sesji wypełnia się z zapytania (2 fotografów po 450 zł, fotobudka 800)',
          owner.input_value('#f-title').startswith('Wesele') and owner.input_value('#f-n-photographer') == '2' and owner.input_value('#f-r-photographer') == '450' and owner.input_value('#f-r-photobooth') == '800' and owner.input_value('#f-loc') == 'Kraków, Dwór Zielony',
          [owner.input_value(i) for i in ['#f-title', '#f-n-photographer', '#f-r-photographer', '#f-r-photobooth']])
    owner.get_by_role('button', name='Dodaj sesję').last.click()
    owner.get_by_text('Sesja dodana.').wait_for()
    st = sql("select status || ':' || (session_id is not null)::text from public.inquiries")
    check('zapytanie oznaczone jako zarezerwowane i połączone z sesją', st == 'booked:true', st)
    sess = json.loads(sql("select row_to_json(s)::text from public.sessions s where inquiry_id is not null"))
    check('nowa sesja ma wymagany personel z zapytania', sess['slots']['photographer']['n'] == 2 and sess['slots']['photobooth']['n'] == 1 and sess['slots'].get('videographer', {}).get('n', 0) == 0, sess['slots'])
    ola.reload(); ola.locator('.tabs').wait_for()
    check('pracownik od razu widzi wolne role z rezerwacji', ola.locator('.sess', has_text='Wesele').count() >= 1 and 'brakuje' in ola.locator('.sess', has_text='Anna Nowak').first.inner_text())

    print('Sesja logowania')
    api('/mock/expire', {})
    ola.locator('.sess', has_text='Anna Nowak').first.locator('.role.photo').get_by_role('button', name='Biorę').click()
    ola.locator('.sess', has_text='Anna Nowak').first.locator('.role.photo .chip.me').wait_for()
    check('wygasły token odświeża się sam, zapis się udaje', True)
    ola.evaluate("() => { const s = JSON.parse(localStorage.getItem('vero.session.v1')); s.refresh = 'zepsuty'; s.exp = 0; localStorage.setItem('vero.session.v1', JSON.stringify(s)); }")
    ola.reload(); ola.locator('#login').wait_for()
    check('nieodnawialna sesja prowadzi do ekranu logowania', 'Panel ekipy Vero Studio' in text_of(ola))
    ola.get_by_role('button', name='Wyloguj').count()
    owner.get_by_role('button', name='Wyloguj').click(); owner.locator('#login').wait_for()
    check('wylogowanie czyści sesję', owner.evaluate("() => localStorage.getItem('vero.session.v1')") is None)
    owner.reload(); owner.locator('#login').wait_for()
    check('po odświeżeniu nadal wylogowany', True)

    print('Błędy JS')
    for name, p in [('owner', owner), ('ola', ola), ('pawel', pawel), ('kasia', kasia)]:
        check('brak błędów JS: ' + name, not p.errors, p.errors)
    browser.close()

print('\nWynik: %d zaliczonych, %d niezaliczonych' % (passed, failed))
sys.exit(1 if failed else 0)
